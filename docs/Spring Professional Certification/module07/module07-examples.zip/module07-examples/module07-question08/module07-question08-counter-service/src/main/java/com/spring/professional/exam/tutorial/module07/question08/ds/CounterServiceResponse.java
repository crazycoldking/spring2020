package com.spring.professional.exam.tutorial.module07.question08.ds;

public class CounterServiceResponse {
    private int number;

    public CounterServiceResponse(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }
}
