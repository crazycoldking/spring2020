insert into customer(id, code, first_name, last_name) values(1, 'CC', 'Caitlin', 'Chen');
insert into customer(id, code, first_name, last_name) values(2, 'KT', 'Kamila', 'Terry');
insert into customer(id, code, first_name, last_name) values(3, 'EH', 'Eve', 'Harrell');
