package com.spring.professional.exam.tutorial.module07.question17;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@ComponentScan
@EnableWebMvc
public class AppConfiguration {
}
