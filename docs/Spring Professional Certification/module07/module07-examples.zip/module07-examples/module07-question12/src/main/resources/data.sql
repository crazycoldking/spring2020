insert into customer(id, code, first_name, last_name) values(1, 'CC', 'Caitlin', 'Chen');
insert into customer(id, code, first_name, last_name) values(2, 'KT', 'Kamila', 'Terry');
insert into customer(id, code, first_name, last_name) values(3, 'EH', 'Eve', 'Harrell');

insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code) values(1, 'Home Address', 3992, 'Buffalo Creek Road', 12, 'Nashville', 'TN', '37209');
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code) values(2, 'Business Address', 2337, 'Bastin Drive', 14, 'Northampton', 'PA', '18067');
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code) values(3, 'Apartment Address', 1758, 'Ritter Avenue', 5, 'Roseville', 'MI', '48066');
