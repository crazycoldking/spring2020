insert into customer(id, code, first_name, last_name) values(1, 'CC', 'Caitlin', 'Chen');
insert into customer(id, code, first_name, last_name) values(2, 'KT', 'Kamila', 'Terry');
insert into customer(id, code, first_name, last_name) values(3, 'EH', 'Eve', 'Harrell');
insert into customer(id, code, first_name, last_name) values(4, 'AH', 'Adalyn', 'Hooper');
insert into customer(id, code, first_name, last_name) values(5, 'CF', 'Chase', 'Freeman');
