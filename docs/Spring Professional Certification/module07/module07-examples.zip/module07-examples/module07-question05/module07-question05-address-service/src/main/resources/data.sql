insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code) values(1, 'Home Address', 3992, 'Buffalo Creek Road', 12, 'Nashville', 'TN', '37209');
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code) values(2, 'Business Address', 2337, 'Bastin Drive', 14, 'Northampton', 'PA', '18067');
