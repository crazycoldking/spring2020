package com.spring.professional.exam.tutorial.module07.question20.jpa;

import java.io.Serializable;

public interface Identifiable {

    Serializable getId();
}
