insert into employee(id, first_name, last_name, phone_number, address, cubicle_no) values(1, 'Ayana', 'Watson', '+1-202-555-0178', '723 Edgewood Drive Alpharetta, GA 30004', 'KL-02');
insert into employee(id, first_name, last_name, phone_number, address, cubicle_no) values(2, 'Azul', 'Booth', '+1-202-555-0182', '7515 Grand Ave. Conway, SC 29526', 'KL-05');
insert into employee(id, first_name, last_name, phone_number, address, cubicle_no) values(3, 'Kael', 'Bowen', '+1-202-555-0142', '986 Lake Dr. Reynoldsburg, OH 43068', 'KR-04');
insert into employee(id, first_name, last_name, phone_number, address, cubicle_no) values(4, 'Jaiden', 'Bush', '+1-202-555-0170', '955 East 10th Avenue Roslindale, MA 02131', 'FW-03');
insert into employee(id, first_name, last_name, phone_number, address, cubicle_no) values(5, 'Maddison', 'Carpenter', '+1-202-555-0146', '8804 Branch Ave. Dalton, GA 30721', 'QA-04');
