package com.spring.professional.exam.tutorial.module06.question07.security;

public interface SecurityRoles {
    String SUPER_ADMIN = "SUPER_ADMIN";

    String EMPLOYEES_ADMIN = "EMPLOYEES_ADMIN";
    String EMPLOYEES_PAG_VIEW = "EMPLOYEES_PAG_VIEW";

}
