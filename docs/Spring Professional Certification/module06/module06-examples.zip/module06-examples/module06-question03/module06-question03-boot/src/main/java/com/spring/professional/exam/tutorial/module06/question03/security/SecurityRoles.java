package com.spring.professional.exam.tutorial.module06.question03.security;

public interface SecurityRoles {
    String ADMIN = "ADMIN";
}
