package com.spring.professional.exam.tutorial.module08.question01;

import com.googlecode.junittoolbox.SuiteClasses;
import com.googlecode.junittoolbox.WildcardPatternSuite;
import org.junit.runner.RunWith;

@RunWith(WildcardPatternSuite.class)
@SuiteClasses("**/*IntegrationTest.class")
public class IntegrationTestsSuite {
}