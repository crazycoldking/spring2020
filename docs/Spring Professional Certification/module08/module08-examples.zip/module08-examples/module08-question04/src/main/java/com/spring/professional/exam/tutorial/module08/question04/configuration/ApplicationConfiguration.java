package com.spring.professional.exam.tutorial.module08.question04.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.spring.professional.exam.tutorial.module08.question04")
public class ApplicationConfiguration {
}
