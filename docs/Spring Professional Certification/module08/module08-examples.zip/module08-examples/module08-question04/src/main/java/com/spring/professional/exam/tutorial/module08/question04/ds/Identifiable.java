package com.spring.professional.exam.tutorial.module08.question04.ds;

public interface Identifiable {
    Integer getId();
}
