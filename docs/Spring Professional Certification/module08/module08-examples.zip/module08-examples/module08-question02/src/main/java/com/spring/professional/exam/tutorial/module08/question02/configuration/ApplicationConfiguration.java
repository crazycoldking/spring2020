package com.spring.professional.exam.tutorial.module08.question02.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.spring.professional.exam.tutorial.module08.question02")
public class ApplicationConfiguration {
}
