package com.spring.professional.exam.tutorial.module01.question10.stereotypes.ds;

public class TaxRate {
}
