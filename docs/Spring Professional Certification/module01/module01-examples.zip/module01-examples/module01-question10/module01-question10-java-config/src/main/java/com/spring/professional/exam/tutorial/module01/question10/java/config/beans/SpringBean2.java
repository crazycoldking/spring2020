package com.spring.professional.exam.tutorial.module01.question10.java.config.beans;

public class SpringBean2 {
    public SpringBean2() {
        System.out.println(getClass().getSimpleName() + "::constructor");
    }
}
