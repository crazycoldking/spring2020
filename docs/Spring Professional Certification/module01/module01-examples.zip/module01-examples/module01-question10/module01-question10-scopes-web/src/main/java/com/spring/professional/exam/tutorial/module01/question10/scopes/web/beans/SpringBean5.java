package com.spring.professional.exam.tutorial.module01.question10.scopes.web.beans;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.ApplicationScope;

@Component
@ApplicationScope
public class SpringBean5 {
}
