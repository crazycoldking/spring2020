package com.spring.professional.exam.tutorial.module01.question17.writer;

import com.spring.professional.exam.tutorial.module01.question17.ds.Report;

public interface ReportWriter {
    void write(Report report, String reportName);
}
