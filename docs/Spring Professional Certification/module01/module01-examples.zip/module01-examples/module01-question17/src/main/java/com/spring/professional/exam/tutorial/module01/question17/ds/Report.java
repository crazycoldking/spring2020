package com.spring.professional.exam.tutorial.module01.question17.ds;

public class Report {
}
