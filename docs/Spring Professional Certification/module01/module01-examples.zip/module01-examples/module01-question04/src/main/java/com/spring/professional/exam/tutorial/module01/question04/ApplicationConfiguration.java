package com.spring.professional.exam.tutorial.module01.question04;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class ApplicationConfiguration {
}
