package com.spring.professional.exam.tutorial.module01.question18;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class ApplicationConfig {
}
