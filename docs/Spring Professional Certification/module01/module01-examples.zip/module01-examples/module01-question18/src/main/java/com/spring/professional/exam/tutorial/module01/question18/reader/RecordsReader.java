package com.spring.professional.exam.tutorial.module01.question18.reader;

import com.spring.professional.exam.tutorial.module01.question18.ds.Record;

import java.util.Collection;

public interface RecordsReader {
    Collection<Record> readRecords();
}
