package com.spring.professional.exam.tutorial.module01.question18.ds;

public class Record {
}
