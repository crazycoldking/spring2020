package com.spring.professional.exam.tutorial.module01.question22.beans;

public class SpringBean1 {
}
