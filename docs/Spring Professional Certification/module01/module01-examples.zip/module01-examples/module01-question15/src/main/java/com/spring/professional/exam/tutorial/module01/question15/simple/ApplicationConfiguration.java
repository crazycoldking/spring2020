package com.spring.professional.exam.tutorial.module01.question15.simple;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class ApplicationConfiguration {
}
