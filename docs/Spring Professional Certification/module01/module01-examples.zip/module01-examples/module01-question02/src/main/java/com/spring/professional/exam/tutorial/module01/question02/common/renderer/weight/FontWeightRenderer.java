package com.spring.professional.exam.tutorial.module01.question02.common.renderer.weight;

import com.spring.professional.exam.tutorial.module01.question02.common.renderer.Renderer;

public interface FontWeightRenderer extends Renderer {
}
