package com.spring.professional.exam.tutorial.module01.question02.common.renderer;

public interface Renderer {
    String render(String text);
}
