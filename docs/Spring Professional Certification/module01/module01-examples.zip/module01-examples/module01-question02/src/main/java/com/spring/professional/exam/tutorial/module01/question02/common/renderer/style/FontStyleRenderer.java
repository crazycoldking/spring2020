package com.spring.professional.exam.tutorial.module01.question02.common.renderer.style;

import com.spring.professional.exam.tutorial.module01.question02.common.renderer.Renderer;

public interface FontStyleRenderer extends Renderer {
}
