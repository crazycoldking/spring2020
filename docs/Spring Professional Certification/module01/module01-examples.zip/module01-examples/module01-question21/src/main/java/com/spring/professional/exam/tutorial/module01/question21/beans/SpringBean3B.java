package com.spring.professional.exam.tutorial.module01.question21.beans;

public class SpringBean3B implements SpringBean3 {
    @Override
    public void printHash() {
        System.out.println("No implemented yet");
    }
}
