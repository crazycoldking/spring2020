package com.spring.professional.exam.tutorial.module01.question09.web;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class ApplicationConfiguration {
}
