package com.spring.professional.exam.tutorial.module01.question13.beans;

import org.springframework.stereotype.Component;

@Component
public class SpringBean2 {
}
