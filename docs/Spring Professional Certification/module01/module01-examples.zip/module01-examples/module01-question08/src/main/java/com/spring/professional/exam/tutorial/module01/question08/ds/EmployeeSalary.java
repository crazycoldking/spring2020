package com.spring.professional.exam.tutorial.module01.question08.ds;

public class EmployeeSalary {
}
