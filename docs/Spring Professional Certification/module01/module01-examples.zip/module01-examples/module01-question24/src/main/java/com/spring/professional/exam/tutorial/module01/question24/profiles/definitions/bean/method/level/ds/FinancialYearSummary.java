package com.spring.professional.exam.tutorial.module01.question24.profiles.definitions.bean.method.level.ds;

public class FinancialYearSummary {
}
