package com.spring.professional.exam.tutorial.module01.question24.profiles.definitions.configuration.level.ds;

public class FinancialReport {
}
