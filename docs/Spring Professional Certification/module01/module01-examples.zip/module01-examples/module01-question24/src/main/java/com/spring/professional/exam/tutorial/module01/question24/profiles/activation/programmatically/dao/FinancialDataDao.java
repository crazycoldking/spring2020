package com.spring.professional.exam.tutorial.module01.question24.profiles.activation.programmatically.dao;

public interface FinancialDataDao {
}
