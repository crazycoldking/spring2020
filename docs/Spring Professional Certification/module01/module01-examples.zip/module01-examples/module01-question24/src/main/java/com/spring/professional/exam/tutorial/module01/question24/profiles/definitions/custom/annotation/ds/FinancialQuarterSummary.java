package com.spring.professional.exam.tutorial.module01.question24.profiles.definitions.custom.annotation.ds;

public class FinancialQuarterSummary {
}
