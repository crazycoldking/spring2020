package com.spring.professional.exam.tutorial.module01.question06.web.servlet2.beans;

public class SpringBean2 {
    public SpringBean2() {
        System.out.println(getClass().getSimpleName() + "::constructor");
    }
}
