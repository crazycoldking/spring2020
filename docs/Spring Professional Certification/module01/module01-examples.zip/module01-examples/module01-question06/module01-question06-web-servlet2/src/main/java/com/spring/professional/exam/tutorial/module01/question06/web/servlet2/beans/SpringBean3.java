package com.spring.professional.exam.tutorial.module01.question06.web.servlet2.beans;

public class SpringBean3 {
    public SpringBean3() {
        System.out.println(getClass().getSimpleName() + "::constructor");
    }
}
