package com.spring.professional.exam.tutorial.module01.question11.beans;

public class SpringBean8 {
    public SpringBean8() {
        System.out.println("Creating " + getClass().getSimpleName() + " - Bean from Configuration class");
    }
}
