package com.spring.professional.exam.tutorial.module01.question11.beans;

public class SpringBean7 {
    public SpringBean7() {
        System.out.println("Creating " + getClass().getSimpleName() + " - Bean from Configuration class");
    }
}
