package com.spring.professional.exam.tutorial.module01.question16.writer;

import com.spring.professional.exam.tutorial.module01.question16.ds.Record;

import java.util.Collection;

public interface RecordsWriter {
    void writeRecords(Collection<Record> records);
}
