package com.spring.professional.exam.tutorial.module01.question16.reader;

import com.spring.professional.exam.tutorial.module01.question16.ds.Record;

import java.util.Collection;

public interface RecordsReader {
    Collection<Record> readRecords();
}
