package com.spring.professional.exam.tutorial.module01.question16.ds;

public class Record {
}
