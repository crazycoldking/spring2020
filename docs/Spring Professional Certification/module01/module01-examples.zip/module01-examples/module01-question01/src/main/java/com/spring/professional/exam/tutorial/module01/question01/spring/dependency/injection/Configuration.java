package com.spring.professional.exam.tutorial.module01.question01.spring.dependency.injection;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.spring.professional.exam.tutorial.module01.question01")
public class Configuration {
}
