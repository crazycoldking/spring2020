package com.spring.professional.exam.tutorial.module01.question01.commons.ds;

public class EmployeeSalary {
}
