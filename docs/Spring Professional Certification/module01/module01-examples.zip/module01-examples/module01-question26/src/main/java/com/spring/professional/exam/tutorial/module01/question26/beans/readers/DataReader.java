package com.spring.professional.exam.tutorial.module01.question26.beans.readers;

public interface DataReader {
}
