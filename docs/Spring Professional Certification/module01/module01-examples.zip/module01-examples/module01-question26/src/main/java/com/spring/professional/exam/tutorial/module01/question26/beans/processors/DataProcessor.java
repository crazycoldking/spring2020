package com.spring.professional.exam.tutorial.module01.question26.beans.processors;

public interface DataProcessor {
}
