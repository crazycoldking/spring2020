package com.spring.professional.exam.tutorial.module01.question26.beans.mappers;

import org.springframework.stereotype.Component;

@Component
public class DataMapper {
}
