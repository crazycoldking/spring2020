package com.spring.professional.exam.tutorial.module01.question23.beans;

public class SpringBean1 {
}
