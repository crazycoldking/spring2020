package com.spring.professional.exam.tutorial.module01.question19.proxy.spring;

public class SpringBean {
}
