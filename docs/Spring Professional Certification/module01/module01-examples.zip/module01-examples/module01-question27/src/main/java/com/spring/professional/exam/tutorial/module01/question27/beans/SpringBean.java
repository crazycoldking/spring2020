package com.spring.professional.exam.tutorial.module01.question27.beans;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("Profile-9999999")
public class SpringBean {
}
