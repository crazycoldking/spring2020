package com.spring.professional.exam.tutorial.module01.question25.beans.writer;

public class DevDataWriter implements DataWriter {
}
