package com.spring.professional.exam.tutorial.module01.question25.beans.readers;

public interface DataReader {
}
