package com.spring.professional.exam.tutorial.module01.question25.beans.readers;

public class DbDataReader implements DataReader {
}
