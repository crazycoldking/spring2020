package com.spring.professional.exam.tutorial.module01.question20.xml.context.beans;

public class SpringBean3 {
}
