package com.spring.professional.exam.tutorial.module01.question20.component.scanning.context.beans;

import org.springframework.stereotype.Component;

@Component
public class SpringBean3 {
}
