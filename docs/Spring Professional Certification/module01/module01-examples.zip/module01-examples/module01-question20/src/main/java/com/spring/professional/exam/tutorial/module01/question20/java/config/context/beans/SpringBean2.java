package com.spring.professional.exam.tutorial.module01.question20.java.config.context.beans;

public class SpringBean2 {
}
