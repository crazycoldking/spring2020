package com.spring.professional.exam.tutorial.module01.question03.ds;

public class FinancialMonthSummary {
}
