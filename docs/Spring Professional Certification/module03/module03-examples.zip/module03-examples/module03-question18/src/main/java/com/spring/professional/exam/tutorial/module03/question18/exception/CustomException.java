package com.spring.professional.exam.tutorial.module03.question18.exception;

public class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}
