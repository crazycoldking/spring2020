create table product
(
    id        int,
    name      varchar(32),
    quantity  int,
    price     float,
    available boolean
);
