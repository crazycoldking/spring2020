package com.spring.professional.exam.tutorial.module03.question01.checked.exception;

public class PersonStoreException extends Exception {
}
