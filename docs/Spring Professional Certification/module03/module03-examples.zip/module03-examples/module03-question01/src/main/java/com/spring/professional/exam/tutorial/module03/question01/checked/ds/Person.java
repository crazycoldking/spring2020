package com.spring.professional.exam.tutorial.module03.question01.checked.ds;

public class Person {
}
