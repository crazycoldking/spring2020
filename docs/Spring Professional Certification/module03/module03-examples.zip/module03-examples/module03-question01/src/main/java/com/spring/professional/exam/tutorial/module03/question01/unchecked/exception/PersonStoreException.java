package com.spring.professional.exam.tutorial.module03.question01.unchecked.exception;

public class PersonStoreException extends RuntimeException {
}
