package com.spring.professional.exam.tutorial.module03.question02.application.server;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class ApplicationConfiguration {
}
