drop table if exists employee;

create table employee
(
    employee_id  int,
    first_name   varchar(32),
    last_name    varchar(32),
    email        varchar(32),
    phone_number varchar(32),
    hire_date    date,
    salary       int
);
