package com.spring.professional.exam.tutorial.module03.question16.service;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface EmployeeServiceC {

    void operationC();
}
