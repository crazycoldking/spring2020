package com.spring.professional.exam.tutorial.module03.question16.service;

import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceCImpl implements EmployeeServiceC {
    @Override
    public void operationC() {

    }
}
