package com.spring.professional.exam.tutorial.module03.question16.service;

import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceDImpl implements EmployeeServiceD {
    @Override
    public void operationD() {

    }
}
