package com.spring.professional.exam.tutorial.module03.question16.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EmployeeServiceA {

    public void operationA() {
    }
}
