package com.spring.professional.exam.tutorial.module03.question16.service;

import org.springframework.transaction.annotation.Transactional;

public interface EmployeeServiceD {

    @Transactional
    void operationD();
}
