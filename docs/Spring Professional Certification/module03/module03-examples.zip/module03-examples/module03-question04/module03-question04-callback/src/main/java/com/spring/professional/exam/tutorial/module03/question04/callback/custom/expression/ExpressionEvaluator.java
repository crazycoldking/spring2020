package com.spring.professional.exam.tutorial.module03.question04.callback.custom.expression;

public interface ExpressionEvaluator {
    int evaluate(int a, int b);
}
