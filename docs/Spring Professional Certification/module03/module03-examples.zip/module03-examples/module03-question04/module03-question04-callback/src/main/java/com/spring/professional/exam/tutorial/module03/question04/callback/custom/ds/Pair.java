package com.spring.professional.exam.tutorial.module03.question04.callback.custom.ds;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class Pair {
    private int a;
    private int b;
}
