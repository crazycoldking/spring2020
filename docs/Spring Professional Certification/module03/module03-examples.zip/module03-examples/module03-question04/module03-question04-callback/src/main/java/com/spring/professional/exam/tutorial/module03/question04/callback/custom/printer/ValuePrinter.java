package com.spring.professional.exam.tutorial.module03.question04.callback.custom.printer;

public interface ValuePrinter {
    void print(int value);
}
