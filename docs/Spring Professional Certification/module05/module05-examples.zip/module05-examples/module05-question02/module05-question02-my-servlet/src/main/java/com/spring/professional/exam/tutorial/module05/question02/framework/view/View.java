package com.spring.professional.exam.tutorial.module05.question02.framework.view;

import com.spring.professional.exam.tutorial.module05.question02.framework.model.Model;

public interface View {
    String render(Model model);
}
