package com.spring.professional.exam.tutorial.module05.question02.framework.model;

public interface Model {
    void set(String name, String value);

    String get(String name);
}
