package com.spring.professional.exam.tutorial.module02.question07.beans;

public interface ITaxBean {
    float calculateTax(float value);
}
