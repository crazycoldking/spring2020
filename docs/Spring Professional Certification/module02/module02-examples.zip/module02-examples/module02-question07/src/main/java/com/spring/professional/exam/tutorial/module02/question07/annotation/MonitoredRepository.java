package com.spring.professional.exam.tutorial.module02.question07.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface MonitoredRepository {
}
