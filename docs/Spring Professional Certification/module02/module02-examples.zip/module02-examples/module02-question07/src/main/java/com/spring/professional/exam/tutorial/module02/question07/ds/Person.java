package com.spring.professional.exam.tutorial.module02.question07.ds;

import com.spring.professional.exam.tutorial.module02.question07.annotation.CustomValidation;

@CustomValidation
public class Person {
}
