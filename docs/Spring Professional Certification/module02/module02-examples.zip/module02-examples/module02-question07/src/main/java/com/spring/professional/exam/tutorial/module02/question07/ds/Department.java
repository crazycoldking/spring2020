package com.spring.professional.exam.tutorial.module02.question07.ds;

public class Department {
}
