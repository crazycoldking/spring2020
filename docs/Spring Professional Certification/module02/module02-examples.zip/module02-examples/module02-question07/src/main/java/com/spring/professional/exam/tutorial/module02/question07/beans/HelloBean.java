package com.spring.professional.exam.tutorial.module02.question07.beans;

public class HelloBean {
    public void sayHello(String name, int ex) {
        System.out.println("Hello from Spring Bean for " + name);
    }
}
