package com.spring.professional.exam.tutorial.module02.question04.ds;

public class Employee {
}
