package com.spring.professional.exam.tutorial.module02.question02.bls;

public interface CurrenciesRepository {
    int getCurrenciesCount();
}
