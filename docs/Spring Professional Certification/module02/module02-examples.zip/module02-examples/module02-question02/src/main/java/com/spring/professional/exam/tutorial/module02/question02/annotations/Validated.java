package com.spring.professional.exam.tutorial.module02.question02.annotations;

import java.lang.annotation.Retention;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Retention(RUNTIME)
public @interface Validated {
}
