package com.spring.professional.exam.tutorial.module02.question02.bls;

import org.springframework.stereotype.Component;

@Component
public class CurrenciesRepositoryImpl implements CurrenciesRepository {
    @Override
    public int getCurrenciesCount() {
        return 0;
    }
}
