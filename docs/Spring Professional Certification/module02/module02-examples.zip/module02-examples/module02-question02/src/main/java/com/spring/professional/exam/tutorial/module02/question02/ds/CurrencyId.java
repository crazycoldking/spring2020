package com.spring.professional.exam.tutorial.module02.question02.ds;

import com.spring.professional.exam.tutorial.module02.question02.annotations.Validated;

@Validated
public enum CurrencyId {
    EUR, USD
}
