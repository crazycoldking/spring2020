package com.spring.professional.exam.tutorial.module02.question01.with.aop.ds;

public class FormattedReport extends Report {
    public FormattedReport(Report report) {
    }
}
