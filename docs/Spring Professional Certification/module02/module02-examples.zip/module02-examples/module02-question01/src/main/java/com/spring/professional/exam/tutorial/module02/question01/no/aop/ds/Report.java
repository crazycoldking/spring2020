package com.spring.professional.exam.tutorial.module02.question01.no.aop.ds;

public class Report {
}
