package com.spring.professional.exam.tutorial.module02.question01.with.aop.annotations;

public @interface PerformanceLogger {
}
